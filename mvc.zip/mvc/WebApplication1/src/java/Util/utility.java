/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Util;

import Beans.bean;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author ignite408
 */
public class utility {
     Connection con;
    public Connection getCon()throws Exception{
        String path="jdbc:mysql://localhost:3306/mydb";
        try{
        Class.forName("com.mysql.jdbc.Driver");
        con=DriverManager.getConnection(path,"root","root"); 
        }
        catch(Exception e){            
        }
        return con;
    }
    
     public String find(bean obj)throws Exception{
        String res="";
        String us=obj.getUser();
        try{
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select pwd from mytab where user='" + us + "'");
            rs.next();
            res = rs.getString("pwd");
            rs.close();
        } 
        catch(SQLException e){
            e.printStackTrace();
        }
        return res;
    }
}
