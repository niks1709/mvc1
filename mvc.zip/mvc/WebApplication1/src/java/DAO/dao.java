/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Beans.bean;
import Util.utility;
import java.sql.Connection;

/**
 *
 * @author ignite408
 */
public class dao {

    public boolean getValue(bean ob) {
    boolean res=false;  
    utility obj=new utility();
    Connection conn;
    try{
    conn=obj.getCon();
    String pwd=obj.find(ob);
    conn.close();
    if(pwd.equals(ob.getPassword())){
        res=true;
    }
    }
    catch(Exception e){
        
    }
    return res;
    }
    
}
