/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Manager;

import Beans.bean;
import DAO.dao;

/**
 *
 * @author ignite408
 */
public class manager {

    public boolean check(String u, String pw) {
        boolean res=false;
        bean ob=new bean();
        ob.setUser(u);
        ob.setPassword(pw);
        res=new dao().getValue(ob);
        return res;
    }
//
//    public boolean insert(String u, String a, String g, String c) {
//        boolean res=false;
//        bean ob=new bean();
//        ob.setUser(u);
//        ob.setPassword(a);
//        res=new dao().getValue(ob);
//        return res;    
//    }
//    
}
